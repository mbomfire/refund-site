
# RefundEase

RefundEase is a minimal web app that allows admins to manage customer refund requests and balances.

## 🚀 Deploy on Render

1. Push this project to GitHub.
2. Go to [render.com](https://render.com), create a new Web Service.
3. Connect your GitHub repo.
4. Set:
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `python app.py`

## 🧰 Tech Stack

- Python Flask
- Flask-Login (Auth)
- SQLite DB

## 📁 Structure

- `app.py`: Main Flask app
- `templates/`: HTML pages
- `static/`: CSS and images
